vendored/SDL/CMakeFiles/SDL3-shared.dir/src/locale/unix/SDL_syslocale.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/locale/unix/SDL_syslocale.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/locale/unix/../SDL_syslocale.h
