vendored/SDL/CMakeFiles/SDL3-shared.dir/src/dialog/SDL_dialog_utils.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/dialog/SDL_dialog_utils.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/dialog/SDL_dialog_utils.h
