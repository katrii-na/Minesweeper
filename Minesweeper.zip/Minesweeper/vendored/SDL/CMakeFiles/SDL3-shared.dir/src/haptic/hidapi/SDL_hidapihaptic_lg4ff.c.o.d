vendored/SDL/CMakeFiles/SDL3-shared.dir/src/haptic/hidapi/SDL_hidapihaptic_lg4ff.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/haptic/hidapi/SDL_hidapihaptic_lg4ff.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/haptic/hidapi/SDL_hidapihaptic_c.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_haptic.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_joystick.h \
 /home/katrina/Desktop/vendored/SDL/src/haptic/hidapi/../SDL_syshaptic.h \
 /home/katrina/Desktop/vendored/SDL/src/haptic/hidapi/../../joystick/SDL_joystick_c.h \
 /home/katrina/Desktop/vendored/SDL/src/haptic/hidapi/../../joystick/SDL_sysjoystick.h \
 /home/katrina/Desktop/vendored/SDL/src/haptic/hidapi/../../joystick/SDL_joystick_c.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_thread.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_mutex.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_timer.h \
 /usr/include/math.h
