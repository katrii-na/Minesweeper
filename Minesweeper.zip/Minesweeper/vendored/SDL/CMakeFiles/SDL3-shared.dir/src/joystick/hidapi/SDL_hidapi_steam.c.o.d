vendored/SDL/CMakeFiles/SDL3-shared.dir/src/joystick/hidapi/SDL_hidapi_steam.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/SDL_hidapi_steam.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/../../SDL_hints_c.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/../../SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/../SDL_sysjoystick.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/../SDL_joystick_c.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/SDL_hidapijoystick_c.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/../usb_ids.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/steam/controller_constants.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/steam/controller_structs.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/steam/controller_structs.h
