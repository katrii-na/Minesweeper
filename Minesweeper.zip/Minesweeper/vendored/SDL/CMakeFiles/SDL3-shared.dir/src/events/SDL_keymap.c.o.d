vendored/SDL/CMakeFiles/SDL3-shared.dir/src/events/SDL_keymap.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/events/SDL_keymap.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/events/SDL_keymap_c.h \
 /home/katrina/Desktop/vendored/SDL/src/events/SDL_keyboard_c.h
