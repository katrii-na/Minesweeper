vendored/SDL/CMakeFiles/SDL3-shared.dir/src/render/gpu/SDL_render_gpu.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/render/gpu/SDL_render_gpu.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/render/gpu/../../events/SDL_windowevents_c.h \
 /home/katrina/Desktop/vendored/SDL/src/render/gpu/../../video/SDL_pixels_c.h \
 /home/katrina/Desktop/vendored/SDL/src/render/gpu/../../video/SDL_blit.h \
 /home/katrina/Desktop/vendored/SDL/src/render/gpu/../SDL_d3dmath.h \
 /home/katrina/Desktop/vendored/SDL/src/render/gpu/../SDL_sysrender.h \
 /home/katrina/Desktop/vendored/SDL/src/render/gpu/../../video/SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/render/gpu/../SDL_yuv_sw_c.h \
 /home/katrina/Desktop/vendored/SDL/src/render/gpu/SDL_gpu_util.h \
 /home/katrina/Desktop/vendored/SDL/src/render/gpu/SDL_pipeline_gpu.h \
 /home/katrina/Desktop/vendored/SDL/src/render/gpu/SDL_shaders_gpu.h
