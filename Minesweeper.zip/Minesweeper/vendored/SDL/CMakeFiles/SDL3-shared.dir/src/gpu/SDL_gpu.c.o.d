vendored/SDL/CMakeFiles/SDL3-shared.dir/src/gpu/SDL_gpu.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/gpu/SDL_gpu.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/gpu/SDL_sysgpu.h \
 /home/katrina/Desktop/vendored/SDL/src/gpu/../video/SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_vulkan.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_stdinc.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_error.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_video.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_begin_code.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_close_code.h \
 /home/katrina/Desktop/vendored/SDL/src/gpu/../video/SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/gpu/../video/SDL_blit.h
