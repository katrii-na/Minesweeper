vendored/SDL/CMakeFiles/SDL3-shared.dir/src/power/SDL_power.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/power/SDL_power.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/power/SDL_syspower.h
