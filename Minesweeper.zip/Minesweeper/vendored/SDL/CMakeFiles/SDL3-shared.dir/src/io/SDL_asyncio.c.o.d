vendored/SDL/CMakeFiles/SDL3-shared.dir/src/io/SDL_asyncio.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/io/SDL_asyncio.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/io/SDL_sysasyncio.h \
 /home/katrina/Desktop/vendored/SDL/src/io/SDL_asyncio_c.h \
 /home/katrina/Desktop/vendored/SDL/src/io/../SDL_internal.h
