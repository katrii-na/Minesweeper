vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/wayland/SDL_waylandmessagebox.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandmessagebox.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandmessagebox.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../dialog/unix/SDL_zenitymessagebox.h
