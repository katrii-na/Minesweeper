vendored/SDL/CMakeFiles/SDL3-shared.dir/src/stdlib/SDL_crc32.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/stdlib/SDL_crc32.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h
