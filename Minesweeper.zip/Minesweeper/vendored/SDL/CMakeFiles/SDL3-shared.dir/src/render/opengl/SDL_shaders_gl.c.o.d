vendored/SDL/CMakeFiles/SDL3-shared.dir/src/render/opengl/SDL_shaders_gl.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/render/opengl/SDL_shaders_gl.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_opengl.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_platform.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_opengl_glext.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdint.h \
 /home/katrina/Desktop/vendored/SDL/src/render/opengl/SDL_shaders_gl.h
