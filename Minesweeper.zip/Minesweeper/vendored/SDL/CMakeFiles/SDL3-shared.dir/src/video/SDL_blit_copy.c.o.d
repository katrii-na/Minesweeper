vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/SDL_blit_copy.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_blit_copy.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_blit.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_blit_copy.h
