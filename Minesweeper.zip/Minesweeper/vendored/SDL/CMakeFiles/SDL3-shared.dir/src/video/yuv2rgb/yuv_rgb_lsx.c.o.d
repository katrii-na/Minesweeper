vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/yuv2rgb/yuv_rgb_lsx.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/yuv2rgb/yuv_rgb_lsx.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/yuv2rgb/yuv_rgb_lsx.h \
 /home/katrina/Desktop/vendored/SDL/src/video/yuv2rgb/yuv_rgb_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/yuv2rgb/yuv_rgb.h \
 /home/katrina/Desktop/vendored/SDL/src/video/yuv2rgb/yuv_rgb_std.h \
 /home/katrina/Desktop/vendored/SDL/src/video/yuv2rgb/yuv_rgb_common.h \
 /home/katrina/Desktop/vendored/SDL/src/video/yuv2rgb/yuv_rgb_sse.h
