CMakeFiles/Start.dir/Mine_Logic.c.o: /home/katrina/Desktop/Mine_Logic.c \
 /usr/include/stdc-predef.h /home/katrina/Desktop/Mine_Logic.h \
 /usr/include/time.h /usr/include/features.h \
 /usr/include/features-time64.h /usr/include/bits/wordsize.h \
 /usr/include/bits/timesize.h /usr/include/sys/cdefs.h \
 /usr/include/bits/long-double.h /usr/include/gnu/stubs.h \
 /usr/include/gnu/stubs-64.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stddef.h \
 /usr/include/bits/time.h /usr/include/bits/types.h \
 /usr/include/bits/typesizes.h /usr/include/bits/time64.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/time_t.h \
 /usr/include/bits/types/struct_tm.h \
 /usr/include/bits/types/struct_timespec.h /usr/include/bits/endian.h \
 /usr/include/bits/endianness.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/timer_t.h \
 /usr/include/bits/types/struct_itimerspec.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/types/__locale_t.h \
 /usr/include/stdlib.h /usr/include/bits/libc-header-start.h \
 /usr/include/bits/waitflags.h /usr/include/bits/waitstatus.h \
 /usr/include/bits/floatn.h /usr/include/bits/floatn-common.h \
 /usr/include/sys/types.h /usr/include/bits/stdint-intn.h \
 /usr/include/endian.h /usr/include/bits/byteswap.h \
 /usr/include/bits/uintn-identity.h /usr/include/sys/select.h \
 /usr/include/bits/select.h /usr/include/bits/types/sigset_t.h \
 /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/alloca.h \
 /usr/include/bits/types/once_flag.h /usr/include/bits/stdlib-float.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_stdinc.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_platform_defines.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdarg.h \
 /usr/include/string.h /usr/include/strings.h /usr/include/wchar.h \
 /usr/include/bits/wchar.h /usr/include/bits/types/wint_t.h \
 /usr/include/bits/types/mbstate_t.h \
 /usr/include/bits/types/__mbstate_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdint.h \
 /usr/include/stdint.h /usr/include/bits/stdint-uintn.h \
 /usr/include/bits/stdint-least.h /usr/include/inttypes.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdbool.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_begin_code.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_close_code.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_assert.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_asyncio.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_atomic.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_audio.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_endian.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_error.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_mutex.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_thread.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_properties.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_iostream.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_bits.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_blendmode.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_camera.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_pixels.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_surface.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_rect.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_clipboard.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_cpuinfo.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_dialog.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_video.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_dlopennote.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_events.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_gamepad.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_guid.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_joystick.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_power.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_sensor.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_keyboard.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_keycode.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_scancode.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_mouse.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_pen.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_touch.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_filesystem.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_gpu.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_haptic.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_hidapi.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_hints.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_init.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_loadso.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_locale.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_log.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_messagebox.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_metal.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_misc.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_platform.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_process.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_render.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_storage.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_system.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_time.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_timer.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_tray.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_version.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_oldnames.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_main.h \
 /usr/include/math.h /usr/include/bits/math-vector.h \
 /usr/include/bits/libm-simd-decl-stubs.h \
 /usr/include/bits/flt-eval-method.h /usr/include/bits/fp-logb.h \
 /usr/include/bits/fp-fast.h /usr/include/bits/mathcalls-macros.h \
 /usr/include/bits/mathcalls-helper-functions.h \
 /usr/include/bits/mathcalls.h /usr/include/bits/mathcalls-narrow.h \
 /usr/include/bits/iscanonical.h /usr/include/stdio.h \
 /usr/include/bits/types/__fpos_t.h /usr/include/bits/types/__fpos64_t.h \
 /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/SDL3_image/SDL_image.h
