vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/wayland/SDL_waylandclipboard.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandclipboard.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylanddatamanager.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandvideo.h \
 /usr/include/EGL/egl.h /usr/include/EGL/eglplatform.h \
 /usr/include/KHR/khrplatform.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdint.h \
 /usr/include/wayland-util.h /usr/include/math.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stddef.h \
 /usr/include/inttypes.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdarg.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_vulkan.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_stdinc.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_error.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_video.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_begin_code.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_close_code.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../SDL_blit.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/linux/SDL_dbus.h \
 /usr/include/dbus-1.0/dbus/dbus.h \
 /usr/lib/dbus-1.0/include/dbus/dbus-arch-deps.h \
 /usr/include/dbus-1.0/dbus/dbus-macros.h \
 /usr/include/dbus-1.0/dbus/dbus-address.h \
 /usr/include/dbus-1.0/dbus/dbus-types.h \
 /usr/include/dbus-1.0/dbus/dbus-errors.h \
 /usr/include/dbus-1.0/dbus/dbus-protocol.h \
 /usr/include/dbus-1.0/dbus/dbus-bus.h \
 /usr/include/dbus-1.0/dbus/dbus-connection.h \
 /usr/include/dbus-1.0/dbus/dbus-memory.h \
 /usr/include/dbus-1.0/dbus/dbus-message.h \
 /usr/include/dbus-1.0/dbus/dbus-shared.h \
 /usr/include/dbus-1.0/dbus/dbus-misc.h \
 /usr/include/dbus-1.0/dbus/dbus-pending-call.h \
 /usr/include/dbus-1.0/dbus/dbus-server.h \
 /usr/include/dbus-1.0/dbus/dbus-signature.h \
 /usr/include/dbus-1.0/dbus/dbus-syntax.h \
 /usr/include/dbus-1.0/dbus/dbus-threads.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/linux/SDL_ime.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylanddyn.h \
 /usr/include/wayland-cursor.h /usr/include/xkbcommon/xkbcommon.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdbool.h \
 /usr/include/stdio.h /usr/include/xkbcommon/xkbcommon-names.h \
 /usr/include/xkbcommon/xkbcommon-keysyms.h \
 /usr/include/xkbcommon/xkbcommon-compat.h \
 /usr/include/xkbcommon/xkbcommon-compose.h \
 /usr/include/wayland-client-core.h /usr/include/wayland-util.h \
 /usr/include/wayland-version.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandsym.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/wayland-client-protocol.h \
 /usr/include/wayland-client.h /usr/include/wayland-client-core.h \
 /usr/include/wayland-client-protocol.h /usr/include/wayland-egl.h \
 /usr/include/wayland-egl-core.h /usr/include/libdecor-0/libdecor.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandwindow.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_touch_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandshmbuffer.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandevents_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_keymap_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_mouse_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_pen_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/../SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_mouse_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandclipboard.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../SDL_clipboard_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_events_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/../video/SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_clipboardevents_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_displayevents_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_dropevents_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_keyboard_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_keymap_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_touch_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_pen_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_windowevents_c.h
