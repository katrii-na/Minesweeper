vendored/SDL/CMakeFiles/SDL3-shared.dir/src/process/SDL_process.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/process/SDL_process.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/process/SDL_sysprocess.h
