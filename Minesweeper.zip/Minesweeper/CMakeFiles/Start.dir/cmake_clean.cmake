file(REMOVE_RECURSE
  "CMakeFiles/Start.dir/link.d"
  "CMakeFiles/Start.dir/Mine_Logic.c.o"
  "CMakeFiles/Start.dir/Mine_Logic.c.o.d"
  "CMakeFiles/Start.dir/Minesweeper.c.o"
  "CMakeFiles/Start.dir/Minesweeper.c.o.d"
  "Start"
  "Start.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/Start.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
