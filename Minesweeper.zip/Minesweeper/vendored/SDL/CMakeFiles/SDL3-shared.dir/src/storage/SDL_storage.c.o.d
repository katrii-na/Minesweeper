vendored/SDL/CMakeFiles/SDL3-shared.dir/src/storage/SDL_storage.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/storage/SDL_storage.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/storage/SDL_sysstorage.h \
 /home/katrina/Desktop/vendored/SDL/src/storage/../filesystem/SDL_sysfilesystem.h
