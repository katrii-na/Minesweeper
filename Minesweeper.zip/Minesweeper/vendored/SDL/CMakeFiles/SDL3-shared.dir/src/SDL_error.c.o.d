vendored/SDL/CMakeFiles/SDL3-shared.dir/src/SDL_error.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/SDL_error.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/stdlib/SDL_vacopy.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_error_c.h
