vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/SDL_video_unsupported.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_video_unsupported.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_video_unsupported.h
