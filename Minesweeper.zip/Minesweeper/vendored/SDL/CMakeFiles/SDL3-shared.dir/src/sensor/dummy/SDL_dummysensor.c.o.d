vendored/SDL/CMakeFiles/SDL3-shared.dir/src/sensor/dummy/SDL_dummysensor.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/sensor/dummy/SDL_dummysensor.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/sensor/dummy/SDL_dummysensor.h \
 /home/katrina/Desktop/vendored/SDL/src/sensor/dummy/../SDL_syssensor.h \
 /home/katrina/Desktop/vendored/SDL/src/sensor/dummy/../SDL_sensor_c.h
