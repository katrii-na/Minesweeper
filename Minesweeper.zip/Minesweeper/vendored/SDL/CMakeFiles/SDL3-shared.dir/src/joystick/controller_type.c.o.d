vendored/SDL/CMakeFiles/SDL3-shared.dir/src/joystick/controller_type.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/joystick/controller_type.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/controller_type.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/controller_list.h
