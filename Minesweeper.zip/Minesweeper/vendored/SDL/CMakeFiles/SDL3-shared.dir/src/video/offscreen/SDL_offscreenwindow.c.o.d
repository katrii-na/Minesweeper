vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/offscreen/SDL_offscreenwindow.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/SDL_offscreenwindow.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_vulkan.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_stdinc.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_error.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_video.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_begin_code.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_close_code.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../SDL_blit.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../../events/SDL_windowevents_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../SDL_egl_c.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_egl.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_platform_defines.h \
 /usr/include/EGL/egl.h /usr/include/EGL/eglplatform.h \
 /usr/include/KHR/khrplatform.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdint.h \
 /usr/include/EGL/eglext.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/SDL_offscreenwindow.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/SDL_offscreenvideo.h
