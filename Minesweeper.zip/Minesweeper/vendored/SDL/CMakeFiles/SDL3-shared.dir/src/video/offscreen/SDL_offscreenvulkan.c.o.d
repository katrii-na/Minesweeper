vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/offscreen/SDL_offscreenvulkan.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/SDL_offscreenvulkan.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../SDL_vulkan_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../wayland/SDL_waylanddyn.h \
 /usr/include/wayland-cursor.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdint.h \
 /usr/include/wayland-util.h /usr/include/math.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stddef.h \
 /usr/include/inttypes.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdarg.h \
 /usr/include/xkbcommon/xkbcommon.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdbool.h \
 /usr/include/stdio.h /usr/include/xkbcommon/xkbcommon-names.h \
 /usr/include/xkbcommon/xkbcommon-keysyms.h \
 /usr/include/xkbcommon/xkbcommon-compat.h \
 /usr/include/xkbcommon/xkbcommon-compose.h \
 /usr/include/wayland-client-core.h /usr/include/wayland-util.h \
 /usr/include/wayland-version.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../wayland/SDL_waylandsym.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/wayland-client-protocol.h \
 /usr/include/wayland-client.h /usr/include/wayland-client-core.h \
 /usr/include/wayland-client-protocol.h /usr/include/wayland-egl.h \
 /usr/include/wayland-egl-core.h /usr/include/libdecor-0/libdecor.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/vulkan.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/vk_platform.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/vulkan_core.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codec_h264std.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codecs_common.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codec_h264std_encode.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codec_h264std.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codec_h265std.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codec_h265std_encode.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codec_h265std.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codec_h264std_decode.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codec_h265std_decode.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codec_av1std.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codec_av1std_decode.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/../vk_video/vulkan_video_codec_av1std.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/vulkan_wayland.h \
 /usr/include/xcb/xcb.h /usr/include/sys/types.h /usr/include/sys/uio.h \
 /usr/include/features.h /usr/include/bits/types/struct_iovec.h \
 /usr/include/bits/uio_lim.h /usr/include/bits/uio-ext.h \
 /usr/include/pthread.h /usr/include/sched.h /usr/include/bits/types.h \
 /usr/include/bits/types/time_t.h \
 /usr/include/bits/types/struct_timespec.h /usr/include/bits/sched.h \
 /usr/include/linux/sched/types.h /usr/include/linux/types.h \
 /usr/include/asm/types.h /usr/include/asm-generic/types.h \
 /usr/include/asm-generic/int-ll64.h /usr/include/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h /usr/include/asm/posix_types.h \
 /usr/include/asm/posix_types_64.h /usr/include/asm-generic/posix_types.h \
 /usr/include/bits/types/struct_sched_param.h /usr/include/bits/cpu-set.h \
 /usr/include/time.h /usr/include/bits/time.h /usr/include/bits/timex.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/struct_tm.h \
 /usr/include/bits/types/clockid_t.h /usr/include/bits/types/timer_t.h \
 /usr/include/bits/types/struct_itimerspec.h \
 /usr/include/bits/types/locale_t.h /usr/include/bits/endian.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/setjmp.h \
 /usr/include/bits/wordsize.h /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct___jmp_buf_tag.h \
 /usr/include/bits/pthread_stack_min-dynamic.h /usr/include/xcb/xproto.h \
 /usr/include/xcb/xcb.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/vulkan_xcb.h \
 /usr/include/X11/Xlib.h /usr/include/X11/X.h \
 /usr/include/X11/Xfuncproto.h /usr/include/X11/Xosdefs.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/.././khronos/vulkan/vulkan_xlib.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_vulkan.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_stdinc.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_error.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_video.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_begin_code.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_close_code.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/offscreen/../SDL_blit.h
