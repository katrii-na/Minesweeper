vendored/SDL/CMakeFiles/SDL3-shared.dir/src/joystick/hidapi/SDL_hidapi_flydigi.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/SDL_hidapi_flydigi.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdint.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/../SDL_sysjoystick.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/../SDL_joystick_c.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/SDL_hidapijoystick_c.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/../usb_ids.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/SDL_hidapi_rumble.h \
 /home/katrina/Desktop/vendored/SDL/src/joystick/hidapi/SDL_hidapi_flydigi.h
