
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/katrina/Desktop/Mine_Logic.c" "CMakeFiles/Start.dir/Mine_Logic.c.o" "gcc" "CMakeFiles/Start.dir/Mine_Logic.c.o.d"
  "/home/katrina/Desktop/Minesweeper.c" "CMakeFiles/Start.dir/Minesweeper.c.o" "gcc" "CMakeFiles/Start.dir/Minesweeper.c.o.d"
  "" "Start" "gcc" "CMakeFiles/Start.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
