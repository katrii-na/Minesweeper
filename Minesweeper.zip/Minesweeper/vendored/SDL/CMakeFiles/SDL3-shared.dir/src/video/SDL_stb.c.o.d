vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/SDL_stb.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_stb.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_stb_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_blit.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_yuv_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/stb_image.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/emmintrin.h \
 /home/katrina/Desktop/vendored/SDL/src/video/miniz.h
