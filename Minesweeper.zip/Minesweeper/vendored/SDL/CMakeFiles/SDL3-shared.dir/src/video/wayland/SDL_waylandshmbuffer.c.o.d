vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/wayland/SDL_waylandshmbuffer.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandshmbuffer.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /usr/include/errno.h /usr/include/features.h /usr/include/bits/errno.h \
 /usr/include/linux/errno.h /usr/include/asm/errno.h \
 /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
 /usr/include/bits/types/error_t.h /usr/include/fcntl.h \
 /usr/include/bits/types.h /usr/include/bits/fcntl.h \
 /usr/include/bits/fcntl-linux.h /usr/include/bits/types/struct_iovec.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stddef.h \
 /usr/include/bits/cloexec.h /usr/include/linux/falloc.h \
 /usr/include/linux/openat2.h /usr/include/linux/types.h \
 /usr/include/asm/types.h /usr/include/asm-generic/types.h \
 /usr/include/asm-generic/int-ll64.h /usr/include/asm/bitsperlong.h \
 /usr/include/asm-generic/bitsperlong.h /usr/include/linux/posix_types.h \
 /usr/include/linux/stddef.h /usr/include/asm/posix_types.h \
 /usr/include/asm/posix_types_64.h /usr/include/asm-generic/posix_types.h \
 /usr/include/bits/openat2.h /usr/include/bits/types/struct_timespec.h \
 /usr/include/bits/stat.h /usr/include/bits/struct_stat.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/limits.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/syslimits.h \
 /usr/include/limits.h /usr/include/bits/libc-header-start.h \
 /usr/include/bits/posix1_lim.h /usr/include/bits/wordsize.h \
 /usr/include/bits/local_lim.h /usr/include/linux/limits.h \
 /usr/include/bits/pthread_stack_min-dynamic.h \
 /usr/include/bits/posix2_lim.h /usr/include/bits/xopen_lim.h \
 /usr/include/bits/uio_lim.h /usr/include/signal.h \
 /usr/include/bits/signum-generic.h /usr/include/bits/signum-arch.h \
 /usr/include/bits/types/sig_atomic_t.h \
 /usr/include/bits/types/sigset_t.h /usr/include/bits/types/siginfo_t.h \
 /usr/include/bits/types/__sigval_t.h /usr/include/bits/siginfo-arch.h \
 /usr/include/bits/siginfo-consts.h \
 /usr/include/bits/siginfo-consts-arch.h \
 /usr/include/bits/types/sigval_t.h /usr/include/bits/types/sigevent_t.h \
 /usr/include/bits/sigevent-consts.h /usr/include/bits/sigaction.h \
 /usr/include/bits/sigcontext.h /usr/include/bits/types/stack_t.h \
 /usr/include/sys/ucontext.h /usr/include/bits/sigstack.h \
 /usr/include/bits/sigstksz.h /usr/include/unistd.h \
 /usr/include/bits/posix_opt.h /usr/include/bits/environments.h \
 /usr/include/bits/confname.h /usr/include/bits/getopt_posix.h \
 /usr/include/bits/getopt_core.h /usr/include/bits/unistd_ext.h \
 /usr/include/linux/close_range.h /usr/include/bits/ss_flags.h \
 /usr/include/bits/types/struct_sigstack.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/sigthread.h \
 /usr/include/bits/types/__sigset_t.h /usr/include/bits/signal_ext.h \
 /usr/include/sys/mman.h /usr/include/bits/mman.h \
 /usr/include/bits/mman-map-flags-generic.h \
 /usr/include/bits/mman-linux.h /usr/include/bits/mman-shared.h \
 /usr/include/bits/mman_ext.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandshmbuffer.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandvideo.h \
 /usr/include/EGL/egl.h /usr/include/EGL/eglplatform.h \
 /usr/include/KHR/khrplatform.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdint.h \
 /usr/include/wayland-util.h /usr/include/math.h /usr/include/inttypes.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdarg.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_vulkan.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_stdinc.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_error.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_video.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_begin_code.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_close_code.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../SDL_blit.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/linux/SDL_dbus.h \
 /usr/include/dbus-1.0/dbus/dbus.h \
 /usr/lib/dbus-1.0/include/dbus/dbus-arch-deps.h \
 /usr/include/dbus-1.0/dbus/dbus-macros.h \
 /usr/include/dbus-1.0/dbus/dbus-address.h \
 /usr/include/dbus-1.0/dbus/dbus-types.h \
 /usr/include/dbus-1.0/dbus/dbus-errors.h \
 /usr/include/dbus-1.0/dbus/dbus-protocol.h \
 /usr/include/dbus-1.0/dbus/dbus-bus.h \
 /usr/include/dbus-1.0/dbus/dbus-connection.h \
 /usr/include/dbus-1.0/dbus/dbus-memory.h \
 /usr/include/dbus-1.0/dbus/dbus-message.h \
 /usr/include/dbus-1.0/dbus/dbus-shared.h \
 /usr/include/dbus-1.0/dbus/dbus-misc.h \
 /usr/include/dbus-1.0/dbus/dbus-pending-call.h \
 /usr/include/dbus-1.0/dbus/dbus-server.h \
 /usr/include/dbus-1.0/dbus/dbus-signature.h \
 /usr/include/dbus-1.0/dbus/dbus-syntax.h \
 /usr/include/dbus-1.0/dbus/dbus-threads.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/linux/SDL_ime.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylanddyn.h \
 /usr/include/wayland-cursor.h /usr/include/xkbcommon/xkbcommon.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdbool.h \
 /usr/include/stdio.h /usr/include/xkbcommon/xkbcommon-names.h \
 /usr/include/xkbcommon/xkbcommon-keysyms.h \
 /usr/include/xkbcommon/xkbcommon-compat.h \
 /usr/include/xkbcommon/xkbcommon-compose.h \
 /usr/include/wayland-client-core.h /usr/include/wayland-util.h \
 /usr/include/wayland-version.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandsym.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/wayland-client-protocol.h \
 /usr/include/wayland-client.h /usr/include/wayland-client-core.h \
 /usr/include/wayland-client-protocol.h /usr/include/wayland-egl.h \
 /usr/include/wayland-egl-core.h /usr/include/libdecor-0/libdecor.h
