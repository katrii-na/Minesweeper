vendored/SDL/CMakeFiles/SDL3-shared.dir/src/render/vitagxm/SDL_render_vita_gxm.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/render/vitagxm/SDL_render_vita_gxm.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h
