vendored/SDL/CMakeFiles/SDL3-shared.dir/src/audio/SDL_audioresample.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/audio/SDL_audioresample.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/audio/SDL_sysaudio.h \
 /home/katrina/Desktop/vendored/SDL/src/audio/SDL_audioresample.h
