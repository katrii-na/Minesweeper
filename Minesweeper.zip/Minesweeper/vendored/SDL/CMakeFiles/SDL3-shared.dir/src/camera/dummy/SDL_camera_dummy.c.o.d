vendored/SDL/CMakeFiles/SDL3-shared.dir/src/camera/dummy/SDL_camera_dummy.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/camera/dummy/SDL_camera_dummy.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/camera/dummy/../SDL_syscamera.h \
 /home/katrina/Desktop/vendored/SDL/src/camera/dummy/../../SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/camera/dummy/../../video/SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/camera/dummy/../../video/SDL_blit.h
