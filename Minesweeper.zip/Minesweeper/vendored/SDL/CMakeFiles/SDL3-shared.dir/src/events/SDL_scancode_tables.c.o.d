vendored/SDL/CMakeFiles/SDL3-shared.dir/src/events/SDL_scancode_tables.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/events/SDL_scancode_tables.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/events/SDL_scancode_tables_c.h \
 /home/katrina/Desktop/vendored/SDL/src/events/scancodes_darwin.h \
 /home/katrina/Desktop/vendored/SDL/src/events/scancodes_linux.h \
 /home/katrina/Desktop/vendored/SDL/src/events/scancodes_xfree86.h
