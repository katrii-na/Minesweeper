vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/wayland/SDL_waylandvideo.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandvideo.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/linux/SDL_system_theme.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/linux/SDL_progressbar.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/linux/../../video/SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_vulkan.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_stdinc.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_error.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_video.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_begin_code.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_close_code.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/linux/../../video/SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/linux/../../video/SDL_blit.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/unix/SDL_gtk.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_events_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/../video/SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_clipboardevents_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_displayevents_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_dropevents_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_keyboard_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_keymap_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_mouse_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_touch_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_pen_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/../SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_windowevents_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandclipboard.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandcolor.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandevents_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_keymap_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_mouse_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_pen_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandvideo.h \
 /usr/include/EGL/egl.h /usr/include/EGL/eglplatform.h \
 /usr/include/KHR/khrplatform.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdint.h \
 /usr/include/wayland-util.h /usr/include/math.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stddef.h \
 /usr/include/inttypes.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdarg.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/linux/SDL_dbus.h \
 /usr/include/dbus-1.0/dbus/dbus.h \
 /usr/lib/dbus-1.0/include/dbus/dbus-arch-deps.h \
 /usr/include/dbus-1.0/dbus/dbus-macros.h \
 /usr/include/dbus-1.0/dbus/dbus-address.h \
 /usr/include/dbus-1.0/dbus/dbus-types.h \
 /usr/include/dbus-1.0/dbus/dbus-errors.h \
 /usr/include/dbus-1.0/dbus/dbus-protocol.h \
 /usr/include/dbus-1.0/dbus/dbus-bus.h \
 /usr/include/dbus-1.0/dbus/dbus-connection.h \
 /usr/include/dbus-1.0/dbus/dbus-memory.h \
 /usr/include/dbus-1.0/dbus/dbus-message.h \
 /usr/include/dbus-1.0/dbus/dbus-shared.h \
 /usr/include/dbus-1.0/dbus/dbus-misc.h \
 /usr/include/dbus-1.0/dbus/dbus-pending-call.h \
 /usr/include/dbus-1.0/dbus/dbus-server.h \
 /usr/include/dbus-1.0/dbus/dbus-signature.h \
 /usr/include/dbus-1.0/dbus/dbus-syntax.h \
 /usr/include/dbus-1.0/dbus/dbus-threads.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../core/linux/SDL_ime.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylanddyn.h \
 /usr/include/wayland-cursor.h /usr/include/xkbcommon/xkbcommon.h \
 /usr/lib/gcc/x86_64-pc-linux-gnu/16/include/stdbool.h \
 /usr/include/stdio.h /usr/include/xkbcommon/xkbcommon-names.h \
 /usr/include/xkbcommon/xkbcommon-keysyms.h \
 /usr/include/xkbcommon/xkbcommon-compat.h \
 /usr/include/xkbcommon/xkbcommon-compose.h \
 /usr/include/wayland-client-core.h /usr/include/wayland-util.h \
 /usr/include/wayland-version.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandsym.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/wayland-client-protocol.h \
 /usr/include/wayland-client.h /usr/include/wayland-client-core.h \
 /usr/include/wayland-client-protocol.h /usr/include/wayland-egl.h \
 /usr/include/wayland-egl-core.h /usr/include/libdecor-0/libdecor.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandwindow.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../../events/SDL_touch_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandshmbuffer.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylanddatamanager.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandkeyboard.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandmessagebox.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandmouse.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandopengles.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../SDL_egl_c.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_egl.h \
 /home/katrina/Desktop/vendored/SDL/include/SDL3/SDL_platform_defines.h \
 /usr/include/EGL/eglext.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/../SDL_sysvideo.h \
 /home/katrina/Desktop/vendored/SDL/src/video/wayland/SDL_waylandvulkan.h \
 /usr/include/fcntl.h /usr/include/features.h /usr/include/bits/types.h \
 /usr/include/bits/fcntl.h /usr/include/bits/fcntl-linux.h \
 /usr/include/bits/types/struct_iovec.h /usr/include/bits/cloexec.h \
 /usr/include/linux/falloc.h /usr/include/linux/openat2.h \
 /usr/include/linux/types.h /usr/include/asm/types.h \
 /usr/include/asm-generic/types.h /usr/include/asm-generic/int-ll64.h \
 /usr/include/asm/bitsperlong.h /usr/include/asm-generic/bitsperlong.h \
 /usr/include/linux/posix_types.h /usr/include/linux/stddef.h \
 /usr/include/asm/posix_types.h /usr/include/asm/posix_types_64.h \
 /usr/include/asm-generic/posix_types.h /usr/include/bits/openat2.h \
 /usr/include/bits/types/struct_timespec.h /usr/include/bits/stat.h \
 /usr/include/bits/struct_stat.h /usr/include/sys/types.h \
 /usr/include/unistd.h /usr/include/bits/posix_opt.h \
 /usr/include/bits/environments.h /usr/include/bits/wordsize.h \
 /usr/include/bits/confname.h /usr/include/bits/getopt_posix.h \
 /usr/include/bits/getopt_core.h /usr/include/bits/unistd_ext.h \
 /usr/include/linux/close_range.h /usr/include/errno.h \
 /usr/include/bits/errno.h /usr/include/linux/errno.h \
 /usr/include/asm/errno.h /usr/include/asm-generic/errno.h \
 /usr/include/asm-generic/errno-base.h /usr/include/bits/types/error_t.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/alpha-modifier-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/cursor-shape-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/fractional-scale-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/frog-color-management-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/idle-inhibit-unstable-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/input-timestamps-unstable-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/keyboard-shortcuts-inhibit-unstable-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/pointer-constraints-unstable-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/primary-selection-unstable-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/relative-pointer-unstable-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/tablet-v2-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/text-input-unstable-v3-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/viewporter-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/xdg-activation-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/xdg-decoration-unstable-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/xdg-dialog-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/xdg-foreign-unstable-v2-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/xdg-output-unstable-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/xdg-shell-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/xdg-toplevel-icon-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/color-management-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/pointer-warp-v1-client-protocol.h \
 /home/katrina/Desktop/Minesweeper/vendored/SDL/wayland-generated-protocols/pointer-gestures-unstable-v1-client-protocol.h
