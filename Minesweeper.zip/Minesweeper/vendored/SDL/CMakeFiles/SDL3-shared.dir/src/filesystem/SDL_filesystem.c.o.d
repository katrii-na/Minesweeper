vendored/SDL/CMakeFiles/SDL3-shared.dir/src/filesystem/SDL_filesystem.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/filesystem/SDL_filesystem.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/filesystem/SDL_filesystem_c.h \
 /home/katrina/Desktop/vendored/SDL/src/filesystem/SDL_sysfilesystem.h \
 /home/katrina/Desktop/vendored/SDL/src/filesystem/../stdlib/SDL_sysstdlib.h
