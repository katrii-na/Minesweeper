vendored/SDL/CMakeFiles/SDL3-shared.dir/src/SDL_properties.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/SDL_properties.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_hints_c.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_properties_c.h
