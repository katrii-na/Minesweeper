vendored/SDL/CMakeFiles/SDL3-shared.dir/src/SDL_list.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/SDL_list.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/./SDL_list.h
