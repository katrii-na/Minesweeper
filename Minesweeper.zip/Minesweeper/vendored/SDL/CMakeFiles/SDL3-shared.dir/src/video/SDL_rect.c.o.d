vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/SDL_rect.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_rect.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_rect_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_rect_impl.h
