vendored/SDL/CMakeFiles/SDL3-shared.dir/src/video/SDL_blit_slow.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_blit_slow.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_blit.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_blit_slow.h \
 /home/katrina/Desktop/vendored/SDL/src/video/SDL_pixels_c.h
