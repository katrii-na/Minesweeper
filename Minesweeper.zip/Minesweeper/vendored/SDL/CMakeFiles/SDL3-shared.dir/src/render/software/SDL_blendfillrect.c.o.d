vendored/SDL/CMakeFiles/SDL3-shared.dir/src/render/software/SDL_blendfillrect.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/render/software/SDL_blendfillrect.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/render/software/SDL_draw.h \
 /home/katrina/Desktop/vendored/SDL/src/render/software/../../video/SDL_surface_c.h \
 /home/katrina/Desktop/vendored/SDL/src/render/software/../../video/SDL_blit.h \
 /home/katrina/Desktop/vendored/SDL/src/render/software/SDL_blendfillrect.h
