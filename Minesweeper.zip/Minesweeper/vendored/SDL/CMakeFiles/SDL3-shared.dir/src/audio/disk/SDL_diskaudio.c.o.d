vendored/SDL/CMakeFiles/SDL3-shared.dir/src/audio/disk/SDL_diskaudio.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/audio/disk/SDL_diskaudio.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/audio/disk/../SDL_sysaudio.h \
 /home/katrina/Desktop/vendored/SDL/src/audio/disk/SDL_diskaudio.h
