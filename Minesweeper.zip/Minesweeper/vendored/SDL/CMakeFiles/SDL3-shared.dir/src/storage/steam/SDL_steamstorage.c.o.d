vendored/SDL/CMakeFiles/SDL3-shared.dir/src/storage/steam/SDL_steamstorage.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/storage/steam/SDL_steamstorage.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/storage/steam/../SDL_sysstorage.h \
 /home/katrina/Desktop/vendored/SDL/src/storage/steam/SDL_steamstorage_proc.h
