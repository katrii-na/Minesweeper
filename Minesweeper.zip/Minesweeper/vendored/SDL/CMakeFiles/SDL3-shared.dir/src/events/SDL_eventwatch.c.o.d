vendored/SDL/CMakeFiles/SDL3-shared.dir/src/events/SDL_eventwatch.c.o: \
 /home/katrina/Desktop/vendored/SDL/src/events/SDL_eventwatch.c \
 /usr/include/stdc-predef.h \
 /home/katrina/Desktop/vendored/SDL/src/SDL_internal.h \
 /home/katrina/Desktop/vendored/SDL/src/events/SDL_eventwatch_c.h
